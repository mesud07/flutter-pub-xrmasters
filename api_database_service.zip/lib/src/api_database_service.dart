import 'package:database_service/database_service.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ApiDatabaseService extends DatabaseService {
  final String url;
  ApiDatabaseService({required this.url});

  @override
  Future<bool> create<T extends Data>(String path, T data) {
    // TODO: implement create
    throw UnimplementedError();
  }

  @override
  Future<T?> get<T extends Data>(String path) {
    // TODO: implement get
    throw UnimplementedError();
  }

  @override
  Future<List<T>?> getAll<T extends Data>(String path) async {
    var json = await getJson(path);
    if (json != null) {
      var dataArray = await jsonDecode(json);
      var list = <T>[];
      for (var data in dataArray) {
        list.add(Data.create<T>(data["id"], data));
      }
      return list;
    }
    return null;
  }

  @override
  Future<bool> set(String path, Data data, {bool append = true}) {
    // TODO: implement set
    throw UnimplementedError();
  }

  Future<String?> getJson(String path) async {
    String apiUrl = url;
    var uri = Uri.parse("$apiUrl/$path");
    var response = await http.get(uri);
    return response.statusCode == 200 ? response.body : null;
  }
}
